class LogicalAddr:
    def __init__(self, address, page_num, offset):
        # Instance attributes (unique to each instance)
        self.address = address
        self.page_num = page_num
        self.offset = offset


